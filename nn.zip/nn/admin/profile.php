<?php require_once "./header.php" ?>
<?php include './conn.php'; ?>
<style>
    .ccc{
        background: linear-gradient(45deg, #47cebe, #ef4a82) !important;
        box-shadow: 8px 10px 10px 8px #888888;
        border: none !important;
        color: #fff !important;
        font-weight: 500 !important;
    }
    .ii{
        background: transparent !important;
        
    }
</style>

<div class="row row-cols-1 row-cols-md-2 g-4">
    <div class="col">
        <div class="card ccc">
            <img src="pic.jpg" class="card-img-top" height="400px" alt="...">

        </div>
    </div>
    <div class="col">
        <form action="#" method="post"></form>
        <div class="card ccc">
            <div class="card-header">
                Admin
            </div>
            <div class="card-body">
              

                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Admin ID</label>
                    <input type="text" class="form-control ii" id="exampleFormControlInput1" >
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Password</label>
                    <input type="password" class="form-control ii" id="exampleFormControlInput1">
                </div>
                <div class="d-grid gap-2 col-6 mx-auto">
                    <button class="btn" style="background-color: #fff;color:#888888" type="button">Change</button>
                </div>

            </div>
        </div>
    </div>
</div>

<?php require_once "./footer.php" ?>