<?php
$con=mysqli_connect('localhost','root','','db_cosmotes1');
if(!$con){
    echo "connected not";
} 
?>