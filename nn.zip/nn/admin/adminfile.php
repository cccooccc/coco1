<?php 
include "../php/conn.php";
?>
<?php
if(isset($_POST['prosub'])){
    $i=$_POST['pi'];
    
    $p=$_POST['ps'];
    
    

    $filenm=$_FILES['file']['name'];
    $basenm=substr($filenm,0,strripos($filenm,'.'));
    $ext=substr($filenm,strripos($filenm,'.'));
    $tmpnm=$_FILES['file']['tmp_name'];
    $alowtyp=array(".jpg",".png");
    if(in_array($ext,$alowtyp)){
        $newfilenm=md5($basenm).rand(10,1000).time().$ext;
        if(file_exists("upload/".$newfilenm)){
            echo "file existst";
        }else{
            move_uploaded_file($tmpnm,"upload/".$newfilenm);
            if($i!=""  && $p!="" ){
                $ip="INSERT INTO admin ( admin_id, password, admiin_pic) VALUES ('$i','$p','$newfilenm')";
                $r=mysqli_query($con,$ip);
                if($r){
                    echo "INSERTED";
                }else{
                    echo "INSERt FAILED";
                }
            }else{
                echo "fiels is empty";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="adminfile.php" method="post" enctype="multipart/form-data">
    <input type="file" name="file"><br>
        <input type="text" name="pi" placeholder="admin ID"><br>
       
        <input type="text" name="ps" placeholder="admin password"><br>
     

        <button type="submit" name="prosub">submit</button>
</body>

</html>