<?php
session_start();
if(isset($_SESSION['usersession'])){
    if(isset($_POST['cart'])){
    if(isset($_SESSION['cart'])){
        $pidd=array_column($_SESSION['cart'],'id');
        //1,2
        if(in_array($_POST['hidid'],$pidd)){
            echo '<script> alert("Product already Added"); window.location.'.$_SESSION['pagestate'].'</script>';
        }else{
                $c=count($_SESSION['cart']);
                $_SESSION['cart'][$c]=array('id'=>$_POST['hidid'],'name'=>$_POST['hidnm'],'price'=>$_POST['hidpr'],'img'=>$_POST['hidimg'],'qty'=>$_POST['hidqty'],'cat'=>$_POST['hidcat']);
                echo '<script> alert("Product Added"); window.location.'.$_SESSION['pagestate'].'</script>';        
            }
    }else{
        $_SESSION['cart'][0]=array('id'=>$_POST['hidid'],'name'=>$_POST['hidnm'],'price'=>$_POST['hidpr'],'img'=>$_POST['hidimg'],'qty'=>$_POST['hidqty'],'cat'=>$_POST['hidcat']);
        echo '<script> alert("Product Added"); window.location.'.$_SESSION['pagestate'].'</script>';
    }
}
if(isset($_POST['inc'])){
    $hid=$_POST['hiddenid'];
    foreach($_SESSION['cart'] as $k=>$v){
        if($hid==$v['id']){
            if($_SESSION['cart'][$k]['qty']<5){
                $_SESSION['cart'][$k]['qty']++;
                echo '<script>window.location.href="cart.php";</script>';

            }else{
                echo '<script> alert("You have Selected Maximum Qty"); window.location.href="cart.php";</script>';
            }

        }
    }
}
if(isset($_POST['dec'])){
    $hid=$_POST['hiddenid'];
    foreach($_SESSION['cart'] as $k=>$v){
        if($hid==$v['id']){
            if($_SESSION['cart'][$k]['qty']>1){
                $_SESSION['cart'][$k]['qty']--;
                echo '<script>window.location.href="cart.php";</script>';

            }else{
                echo '<script>window.location.href="cart.php";</script>';
            }

        }
    }
}
}
if(isset($_POST['rem'])){
    $hid=$_POST['hiddenid'];
    foreach($_SESSION['cart'] as $k=>$v){
        if($hid==$v['id']){
            unset($_SESSION['cart'][$k]);
            $_SESSION['cart']=array_values($_SESSION['cart']);
            echo '<script> alert("Product removed"); window.location.href="cart.php";</script>';
        }
    }
}
else{
    echo '<script> alert("You have to Login First!"); window.location.href="./signin.php"</script>';
}


?>