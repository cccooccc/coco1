<?php require_once "./header.php" ?>
<style>
    .table1 {

        margin-left: 50px;
        margin-right: 50px;

    }

    .tt {
        background: transparent !important;
        color: #fff !important;


    }
    .bb{
        text-decoration: none;
        color: #fff;
        border: 1px solid #2a9191;
        border-radius:12px;
        padding: 12px 34px;
        font-size: 18px;
        background: #2a9191;
        position: relative;
        cursor: pointer;
    }

    .bb:hover {
        border: 1px solid #fff;
        background: transparent;
        color: #fff;
        transition: 0.8s;
    }
</style>

<main>
    <div class="container">
        <div class="row">
            <div class=" text-center border rounded my-5">
                <h3 style="color: #fff;">My Cart</h3>
            </div>
            <div class="col-lg-9">
                <div class="table1">
                    <table class="table text-center table-hover table-bordered ">
                        <thead>
                            <tr>
                                <th class="tt" scope="col">#</th>
                                <th class="tt" scope="col">Photo</th>
                                <th class="tt" scope="col">Name</th>
                                <th class="tt" scope="col">Item Price</th>
                                <th class="tt" scope="col">Qty</th>
                                <th class="tt" scope="col">Total Price</th>
                                <th class="tt" scope="col"></th>

                            </tr>
                        </thead>
                        
                        <tbody><?php
                                $total = 0;
                                foreach ($_SESSION['cart'] as $k => $v) {
                                    $total = $total + $v['price']*$v['qty'];
                                    $sr=$k+1;
                                    echo '<tr>
                                    <th class="tt" scope="row">'.$sr.'</th>
                                    <td class="tt"><img src="../admin/upload/'.$v['img'].'" width="52px" height="60px" alt=""></td>
                                    <td class="tt">' . $v['name'] . '</td>
                                    <td class="tt">' . $v['price'] . '</td>
                                    <td class="tt">
                                    <form action="managecart.php" method="post">
                                    <input type="hidden" name="hiddenid" value="'.$v['id'].'">
                                    <button class="btn btn-sm btn-outline-secondary" name="inc">+</button>
                                    
                                    '.' '. $v['qty'] .' '.'
                                    
                                    <button class="btn btn-sm btn-outline-secondary" name="dec">-</button>
                                    </td>
                                    <td class="tt">'.$v['price']*$v['qty'].'</td>
                                    <td class="tt"><button class="btn btn-sm btn-outline-danger" name="rem">Remove</button></td>
                                    </form>
            </tr>';
                                } ?>


                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-3">
                    <div class="border rounded text-center p-4" style="color: #fff;">
                        <h4><?php echo 'Total : Rs. '.$total; ?></h4>
                        
                        <button class="bb">Make Purchase</button>
                    </div>
            </div>
        </div>
    </div>
</main>

<?php require_once "./footer.php" ?>