<?php require_once "./header.php" ?>
<?php include './conn.php'; ?>
<style>
    .box {
        position: relative;
    }

    .middle {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0;
        transition: opacity 0.4s ease-in-out;
        background: black;
        cursor: pointer;
    }

    .text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: #fff;
        font-family: verdana;
        text-align: left;
    }

    .box:hover .middle {
        opacity: 0.8;

    }

    .catimg {
        box-shadow: rgba(240, 240, 245, 0.4) 0px 7px 29px 0px;
        /* border-radius: 10px; */
        width: 380px;
        height: 450px;

    }

    .btn {
        margin: 0;
        padding: 0;
        border: 0;
        background: none;

    }

    .tt1 {
        background-color: #2a9191;
        color: #fff;
    }

    .tt2 {
        background-color: gray;
        color: #fff;
    }
</style>
<main>
    <div class="container">


        <div class="row">
            <?php
            $sql = "SELECT * FROM beauty_advice";
            $res = mysqli_query($con, $sql);
            if (mysqli_num_rows($res) > 0) {
                $i = 0;
                while ($p = mysqli_fetch_assoc($res)) {
                    $i++;

            ?>
                    <div class="col">

                        <button type="button" name="skin" data-bs-toggle="modal" data-bs-target="#exampleModalCenteredScrollable<?php echo $i; ?>">

                            <div class="box">
                                <img src="../admin/upload/<?php echo ($p['bimg']); ?>" class="catimg" alt="" srcset="">

                                <div class="middle">

                                </div>

                            </div>

                        </button>

                        <div class="modal" id="exampleModalCenteredScrollable<?php echo $i; ?>" tabindex="-1" aria-labelledby="exampleModalLabel<?php echo $i; ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                                <div class="modal-content" >
                                    <div class="modal-header " >
                                        <h1 class="modal-title" id="exampleModalLabel<?php echo $i; ?>"><?php echo $p['title']; ?> </h1>
                                        <!-- <button style="background: red;" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button> -->
                                    </div>
                                    <div class="modal-body">
                                        <p><?php echo $p['des']; ?></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button style="width: 100%;" type="button" class="btn btn-secondary" data-bs-dismiss="modal">OK</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
<?php
                }
            }
?>
    </div>
    </div>
</main>
<?php require_once "./footer.php" ?>